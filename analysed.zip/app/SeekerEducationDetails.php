<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SeekerEducationDetails extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'seeker_education_details';
}
